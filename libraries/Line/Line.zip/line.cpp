//
// Created by Silvina on 29.05.2019.
//

#include "line.h"

line :: line (int in1, int in2, int in3, int in4, int enA, int enB) { //perguntar ao prof sobre isso.
// connect motor controller pins to Arduino digital pins
    int enA = 2;
    int in1 = 3;
    int in2 = 4;   // motor 1
    int in3 = 5;
    int in4 = 6;
    int enB = 7;   // motor 2
}

void line:: Stop()   // stop robot
{
    digitalWrite(in1, LOW);
    digitalWrite(in2, LOW);
    digitalWrite(in3, LOW);
    digitalWrite(in4, LOW);
}

void line::Forward (int LeftSpeed, int RightSpeed) // range 0 - 255
{
    digitalWrite(in1, HIGH); // turn on left motor to forward
    digitalWrite(in2, LOW);
    analogWrite(enA, LeftSpeed);
    digitalWrite(in3, HIGH); // turn on right motor to forward
    digitalWrite(in4, LOW);
    analogWrite(enB, RightSpeed);
}
void line::Reverse (int LeftSpeed, int RightSpeed) // range 0-255
{
    digitalWrite(in1, LOW); // turn on left motor to forward
    digitalWrite(in2, HIGH);
    analogWrite(enA, LeftSpeed);
    digitalWrite(in3, LOW); // turn on right motor to forward
    digitalWrite(in4, HIGH);
    analogWrite(enB, RightSpeed);
}

void line::SetPixelsToSensors()  // turn on NeoPixels that are less than threshold value
{
    for (int n=0; n<=5; n++)
    {
        if (sensor[n] < Threshold[n])
            pixels.setPixelColor(5-n, pixels.Color(40,40,40));
        else
            pixels.setPixelColor(5-n, pixels.Color(0,0,0));
        pixels.show();
    }
}

void line:: setup()
{
    // set all the motor control pins to outputs
    pinMode(enA, OUTPUT);
    pinMode(enB, OUTPUT);
    pinMode(in1, OUTPUT);
    pinMode(in2, OUTPUT);
    pinMode(in3, OUTPUT);
    pinMode(in4, OUTPUT);

    Serial.begin(9600); // used to write to serial monitor
    pixels.begin();     // initialize NeoPixels

    // set up pushbutton
   pinMode(53,INPUT_PULLUP); //Controlador principal

    while (digitalRead(53) != LOW) // loop until pushbutton is pressed
    {
        //for testing QTR, print out sensor value to Serial Monitor
        qtr.read(sensor);
        SetPixelsToSensors();
        Serial.print(sensor[0]); Serial.print(" "); Serial.print(sensor[1]); Serial.print(" ");
        Serial.print(sensor[2]); Serial.print(" "); Serial.print(sensor[3]); Serial.print(" ");
        Serial.print(sensor[4]); Serial.print(" "); Serial.print(sensor[5]); Serial.print(" ");
        Serial.print( sensor[6]); Serial.print(" "); Serial.print(sensor[7]); Serial.print("\n");
        delay(500);
    }
    Forward(50,50);

}

void loop()
{

        qtr.read(sensor);
        SetPixelsToSensors();

        if (sensor[0] < Threshold[0])
        {
            Forward(10, 60);
        } else if (sensor[7] < Threshold[7])
        {
            Forward(60, 10);
        } else if (sensor[1] < Threshold[1])
        {
            Forward(25, 60);
        } else if (sensor[6] < Threshold[6])
        {
            Forward(60, 25);
        } else if (sensor[5] < Threshold[5])
        {
            Forward(60, 40);
        } else if (sensor[2] < Threshold[2])
        {
            Forward(40, 60);
        } else if (sensor[3] < Threshold[3] || sensor[4] < Threshold[4])
        {
            Forward(60, 60);
        } else if (sensor[5] < Threshold[5])
        {
            Forward(60, 40);
        } else
            Forward(60, 60);

        delay(10);
    }
