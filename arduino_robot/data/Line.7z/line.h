//
// Created by Silvina on 29.05.2019.
//

#ifndef ROBOT_LINE_H
#define ROBOT_LINE_H
#include <QTRSensors.h>
#include <Adafruit_NeoPixel.h>

class QTRSensorRc;

class line {
public:

    Adafruit_NeoPixel pixels = Adafruit_NeoPixel(8, 10); // NumPixels, Pin

// Arduino Mega - connect QTR wires to Analog pins 0 - 7
char array[6] = {54, 55, 56, 57, 58, 59};
    QTRSensorsRC qtr(array, 5); // Mega code

// Arduino Uno - connect QTR wires to Analog pins 0 - 5
// QTRSensorsRC qtr((char[]) {14, 15, 16, 17, 18, 19}, 6); // Uno code

    unsigned int sensor[5];  // used to store the value each sensor reads
    // change these to set the the threshold for each sensor to detect a line
    int Threshold[5] = {700, 700, 700, 700, 700};

    int in1;
    int in2;
    int in3;
    int in4;
    int enA;
    int enB;

    line (int in1, int in2, int in3, int in4, int enA, int enB);
    void Stop() const;
    void Forward (int LeftSpeed, int RightSpeed) const;
    void SetPixelsToSensors() const;
    void setup();
    void loop() ;

};


#endif //ROBOT_LINE_H
